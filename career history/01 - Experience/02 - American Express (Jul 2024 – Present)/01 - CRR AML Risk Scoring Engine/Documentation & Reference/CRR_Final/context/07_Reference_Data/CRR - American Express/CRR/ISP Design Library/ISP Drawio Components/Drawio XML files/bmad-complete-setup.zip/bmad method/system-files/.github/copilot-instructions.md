# BMAD Method - Master System Instructions

This file is the **Brain** of the entire BMAD Method folder. It provides context to GitHub Copilot about the complete system architecture.

---

## 📁 Folder Architecture

This project contains **two** primary layers that work together:

### 1. `original/_bmad/` - The Core BMAD System
*   **Purpose:** Contains the complete, modular BMAD Method engine.
*   **Contents:**
    *   `_bmad/bmm/` - BMAD Method Module (PM, Dev, Architect agents + Workflows).
    *   `_bmad/bmb/` - BMAD Builder Module (For creating/editing agents, workflows, modules).
    *   `_bmad/cis/` - Creative Intelligence Suite (Innovation & Design Thinking workflows).
    *   `_bmad/core/` - Core OS (Party Mode, Elicitation, Workflow Engine).
    *   `_bmad/enterprise/` - **Enterprise Delivery Module** (Domain Sentinel, Agile Bridge, Design Architect agents + workflows).
*   **Role:** This is the "Execution Engine". It runs workflows, creates PRDs, generates stories, orchestrates sprints.
*   **Output:** All workflow outputs are written to `_bmad-output/`.

### 2. `custom/` - Team-Specific Configuration & Input Data
*   **Purpose:** Contains team-configurable input data that drives enterprise module behavior.
*   **Contents:**
    *   `product-knowledge/project-context.md` - Product domain knowledge, business rules, tech stack.
    *   `team-config/team-context.yaml` - Team structure, Sprint config, agile tool (Rally/Jira).
    *   `design-system/` - Design system components, manifest, brand guidelines.
    *   `agile-templates/` - Rally/Jira import templates and field mappings.
    *   `architecture-standards/` - Approved tech stack, security requirements, cloud patterns.
*   **Role:** This folder contains **ONLY input data** - no executable code, agents, or workflows.
*   **Customization:** Different teams can maintain their own `custom/` folders with their specific data.

### 3. `_bmad-output/` - System Output Folder
*   **Purpose:** Stores all generated artifacts from BMAD workflows.
*   **Examples:** PRDs, Architecture Docs, Epics & Stories, Sprint Status.
*   **Flow:** Core BMAD writes here; Enterprise agents read from here to apply transformations.

---

## 🔄 Integration Flow (How It Works)

The Enterprise module extends core BMAD capabilities:

1.  **Initialize Team** (`/bmad-enterprise-workflows-initialize-team`)
    - Creates `custom/product-knowledge/project-context.md`
    - Creates `custom/team-config/team-context.yaml`

2.  **Run Core BMAD Workflows** (PRD → Architecture → Epics & Stories)
    - Core agents load context from `custom/product-knowledge/project-context.md`
    - Workflows generate output to `_bmad-output/`

3.  **Transform to Agile Tool Format** (Invoke Agile Bridge)
    - Reads stories from `_bmad-output/`
    - Uses templates from `custom/agile-templates/{rally|jira}/`
    - Outputs Rally/Jira CSV import file

4.  **Generate Wireframes** (Invoke Design Architect)
    - Uses design system from `custom/design-system/`
    - Creates brand-compliant wireframes in Draw.io or Excalidraw format

---

## 🧭 Copilot Directives

When assisting in this project:

1.  **All Executable Logic is in `original/_bmad/`:** Agents and workflows live here, NOT in `custom/`.
2.  **Enterprise Agents:** Located at `original/_bmad/enterprise/agents/` (domain-sentinel, agile-bridge, design-architect).
3.  **Custom Folder is Input-Only:** When teams need to customize behavior, they edit files in `custom/`, never in `original/`.
4.  **Product Context Loading:** All core agents load `custom/product-knowledge/project-context.md` on activation (Step 0).
5. **For Rally/Jira Output:** Invoke `original/_bmad/enterprise/agents/agile-bridge.md` which uses templates from `custom/agile-templates/`.
6.  **For Design System Wireframes:** Invoke `original/_bmad/enterprise/agents/design-architect.md` which references `custom/design-system/`.
7.  **Multi-Team Support:** Different teams can have different `custom/` folders (e.g., `/team-A/custom/`, `/team-B/custom/`) using the SAME `original/_bmad/` codebase.
