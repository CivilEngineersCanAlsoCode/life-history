# Custom Folder - Input Data Only

This `custom/` folder contains **team-specific configuration and input data** that drives the behavior of the Enterprise Delivery module.

## 🎯 Purpose

**This folder contains ONLY input data - no executable code, agents, or workflows.**

The Enterprise agents (located in `original/_bmad/enterprise/`) read from this folder to customize their behavior for your team.

---

## 📁 Folder Structure

```
custom/
├── product-knowledge/         # Product domain knowledge
│   ├── project-context.md     # Main product context (REQUIRED)
│   └── existing-docs/         # Legacy documentation
│
├── team-config/               # Team structure & agile practices
│   └── team-context.yaml      # Team configuration (REQUIRED)
│
├── design-system/             # Design system assets
│   ├── manifest.json          # Design catalog
│   ├── components/samples/    # UI components (SVG, etc.)
│   └── README.md
│
├── agile-templates/           # Rally/Jira templates
│   ├── rally/
│   │   ├── import_templates.csv
│   │   └── field-mappings.yaml
│   └── jira/
│       ├── import_templates.csv
│       └── field-mappings.yaml
│
└── architecture-standards/    # Tech stack & architecture
    ├── tech-stack.yaml
    ├── security-requirements.md
    └── cloud-infrastructure.md
```

---

## 🚀 Getting Started

### Step 1: Replace Sample Files

All files in this folder are **SAMPLES with placeholders**. Replace them with your actual data:

1. **`product-knowledge/project-context.md`** - Your product documentation
2. **`team-config/team-context.yaml`** - Your team structure and Sprint config
3. **`design-system/`** - Your design system components
4. **`agile-templates/`** - Your Rally or Jira configuration
5. **`architecture-standards/`** - Your approved tech stack and standards

### Step 2: Activate Enterprise Agents

Once you've customized the input files, activate the enterprise agents:

- `/domain-sentinel` - Context guardian (loads `project-context.md`)
- `/agile-bridge` - Template enforcer (uses `agile-templates/`)
- `/design-architect` - Wireframe generator (uses `design-system/`)

**The agents automatically read from this `custom/` folder - no code changes needed!**

---

## 🔄 Updating Configuration

To update your team's configuration:

1. Edit the relevant file in `custom/`
2. Save your changes
3. Re-activate the agent - it will load the updated configuration

---

## 🌐 Multi-Team Usage

Different teams can maintain their own `custom/` folders:

```
/team-payments/custom/          # Payments team config
/team-auth/custom/              # Auth team config
/team-analytics/custom/         # Analytics team config
```

Each team uses the SAME enterprise agents (`original/_bmad/enterprise/`) but with their own input data.

---

## ⚠️ Important Notes

- **Never commit sensitive data** (API keys, passwords, etc.) - use placeholders
- **Keep this folder in version control** so team members stay in sync
- **Document your changes** - update this README when adding new files
- **Sample files are safe to delete** after you replace them with real data

---

## 📚 Reference

For more information on the Enterprise Delivery module, see:
- `original/_bmad/enterprise/README.md` - Enterprise module documentation
- `.github/copilot-instructions.md` - System architecture overview
