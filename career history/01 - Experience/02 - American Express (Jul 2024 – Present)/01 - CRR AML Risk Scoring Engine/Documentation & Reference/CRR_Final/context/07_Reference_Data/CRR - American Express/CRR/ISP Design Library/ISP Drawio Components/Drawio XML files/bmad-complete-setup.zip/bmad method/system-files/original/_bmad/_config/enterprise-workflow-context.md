# Enterprise Workflow Context

> **For All Core BMAD Workflows**

This file provides context about enterprise agents and when/how to invoke them.

---

## 🤖 Enterprise Agents Available

### 1. Domain Sentinel
- **Agent Path:** `{project-root}/system-files/original/_bmad/enterprise/agents/domain-sentinel.md`
- **Purpose:** Product context guardian & team configurator
- **When to Use:**
  - Project initialization
  - Update product knowledge
  - Configure team settings

### 2. Agile Bridge
- **Agent Path:** `{project-root}/system-files/original/_bmad/enterprise/agents/agile-bridge.md`
- **Purpose:** Transform BMAD stories to Rally/Jira import format
- **When to Use:**
  - After generating Epics & Stories
  - Before Sprint planning
  - When exporting to Rally/Jira

### 3. Design Architect
- **Agent Path:** `{project-root}/system-files/original/_bmad/enterprise/agents/design-architect.md`
- **Purpose:** Generate design system-compliant wireframes
- **When to Use:**
  - During UX design phase
  - Creating wireframes from requirements
  - Generating Draw.io or Excalidraw mockups

---

## 📋 Workflow Integration Guide

### When Core Workflows Should Invoke Enterprise Agents

| Core Workflow | Enterprise Agent to Invoke | Purpose |
| :--- | :--- | :--- |
| `create-epics-and-stories` | **Agile Bridge** (optional) | Export stories to Rally/Jira format |
| `create-story` | **Agile Bridge** (optional) | Export individual story for import |
| `sprint-planning` | **Agile Bridge** (optional) | Generate Sprint import file |
| `create-ux-design` | **Design Architect** (for design system wireframes) | Create brand-compliant wireframes |
| `create-excalidraw-wireframe` | **Design Architect** (for design components) | Use design system components |

---

## 🔄 Typical Workflow Sequence

1. **Initialize Team** (`/bmad-enterprise-workflows-initialize-team`)
   - Creates `custom/product-knowledge/project-context.md`
   - Creates `custom/team-config/team-context.yaml`

2. **Run Core BMAD Workflows** (PRD → Architecture → Epics & Stories)
   - Workflows load context from `custom/`
   - Generate output to `_bmad-output/`

3. **Transform to Agile Tool Format** (Invoke Agile Bridge)
   - Reads stories from `_bmad-output/`
   - Outputs Rally/Jira CSV import file

4. **Import to Rally/Jira**
   - User uploads generated CSV to their agile tool
