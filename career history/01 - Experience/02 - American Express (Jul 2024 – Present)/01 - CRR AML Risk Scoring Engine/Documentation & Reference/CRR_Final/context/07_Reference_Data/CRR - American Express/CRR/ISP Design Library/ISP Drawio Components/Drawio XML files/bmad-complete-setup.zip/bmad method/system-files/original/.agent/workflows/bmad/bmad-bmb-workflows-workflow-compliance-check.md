---
description: 'Systematic validation of workflows against BMAD standards with adversarial analysis and detailed reporting'
---

IT IS CRITICAL THAT YOU FOLLOW THIS COMMAND: LOAD the FULL @_bmad/bmb/workflows/workflow-compliance-check/workflow.md, READ its entire contents and follow its directions exactly!
