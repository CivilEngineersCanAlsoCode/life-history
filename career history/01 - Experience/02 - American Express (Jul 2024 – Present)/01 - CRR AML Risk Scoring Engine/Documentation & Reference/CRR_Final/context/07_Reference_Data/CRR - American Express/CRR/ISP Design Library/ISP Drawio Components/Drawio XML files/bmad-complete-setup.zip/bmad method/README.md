# BMAD Workspace

Welcome to your **BMAD Workspace** - a clean, organized environment for running BMAD workflows with your team's configuration.

---

## 🚀 Quick Start

```bash
# 1. Clone this repository
git clone https://github.com/klickbae8yt-star/CRR.git my-bmad-workspace
cd my-bmad-workspace

# 2. Initialize the BMAD system files submodule
git submodule update --init --recursive

# 3. Customize your team configuration in custom/ folder

# 4. Start using BMAD workflows
```

---

## 📁 Folder Structure

```
├── system-files/      🔒 BMAD Engine (Read-Only)
├── custom/            ✏️ Your Config (Edit Freely)
└── output/            📤 Generated Files
```

---

## ✏️ Customizing for Your Team

Run initialization workflow:
```bash
/bmad-enterprise-workflows-initialize-team
```

Then edit files in `custom/`:
- `product-knowledge/project-context.md` - Your product info
- `team-config/team-context.yaml` - Team structure
- `design-system/` - UI components
- `agile-templates/` - Rally/Jira config
- `architecture-standards/` - Tech stack

---

## 🔄 Updating BMAD System

```bash
cd system-files
git pull
cd ..
git add system-files
git commit -m "Updated BMAD"
```

---

## ⚠️ Important

- ✅ Edit `custom/` freely
- ❌ Don't edit `system-files/` (read-only submodule)

See `system-files/README.md` and `custom/README.md` for details.
