# Design System README

# 🔴 SAMPLE FILES - Replace with your actual design system assets

This folder contains your organization's design system components and guidelines.

## Structure

```
design-system/
├── manifest.json              # Design system catalog (ISP components, brand colors, etc.)
├── components/samples/        # SVG/React components
│   └── button-primary.svg     # Sample button component
└── drawio-library.xml         # Draw.io component library (if using Draw.io)
```

## How to Use

### For UX Designers
1. Add your design components (SVG, Figma exports, etc.) to `components/`
2. Update `manifest.json` with component catalog
3. If using Draw.io, export your component library to `drawio-library.xml`

### For Developers
- Reference components from this folder in your wireframes and designs
- The **Design Architect** agent will use these components when generating wireframes

## Supported Formats
- SVG (preferred for web components)
- PNG/JPG (for mockups and images)
- Draw.io XML (for technical diagrams)

## Design Tokens
Consider adding a `design-tokens.json` file with:
- Colors (primary, secondary, etc.)
- Typography (font families, sizes, weights)
- Spacing (margin, padding scales)
- Shadows, borders, etc.

---

**Replace these sample files with your actual design system!**
