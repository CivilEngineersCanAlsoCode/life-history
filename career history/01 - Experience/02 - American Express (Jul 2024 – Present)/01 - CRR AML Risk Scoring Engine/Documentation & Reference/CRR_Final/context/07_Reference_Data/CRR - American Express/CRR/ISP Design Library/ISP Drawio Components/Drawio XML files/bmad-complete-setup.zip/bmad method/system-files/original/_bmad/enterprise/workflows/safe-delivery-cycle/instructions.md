# SAFe Delivery Cycle Workflow Instructions

<critical>This workflow orchestrates the full enterprise delivery cycle from PRD to Rally/Jira import</critical>
<critical>Communicate all responses in {communication_language}</critical>

<workflow>

<step n="1" goal="Verify team initialization">
<action>
Check if team is initialized:
- Verify `{product_knowledge}` exists
- Verify `{team_config}` exists

If either is missing:
- Inform {user_name} they must run `/bmad-enterprise-workflows-initialize-team` first
- STOP workflow execution
</action>
</step>

<step n="2" goal="Phase 1 - Planning (PRD Creation)">
<action>
Invoke core workflow: `/bmad-bmm-workflows-create-prd`

This will create a Product Requirements Document with product context from `{product_knowledge}`.

Output: `{prd_output}`
</action>
<ask>
"PRD created. Ready to proceed to Architecture phase? [YES/NO]"
</ask>
</step>

<step n="3" goal="Phase 2 - Architecture">
<action>
Invoke core workflow: `/bmad-bmm-workflows-create-architecture`

This will create architecture decisions using:
- PRD from step 2
- Architecture standards from `{custom_folder}/architecture-standards/`

Output: `{architecture_output}`
</action>
<ask>
"Architecture complete. Ready to break down into Epics & Stories? [YES/NO]"
</ask>
</step>

<step n="4" goal="Phase 3 - Epics & Stories">
<action>
Invoke core workflow: `/bmad-bmm-workflows-create-epics-and-stories`

This will break down PRD + Architecture into actionable epics and user stories.

Output: `{epics_output}`
</action>
<ask>
"Epics & Stories created. Ready to generate Rally/Jira import file? [YES/NO]"
</ask>
</step>

<step n="5" goal="Phase 4 - Generate Agile Tool Import">
<action>
Invoke the Agile Bridge agent:
`{project-root}/system-files/original/_bmad/enterprise/agents/agile-bridge.md`

Instructions to agent:
1. Read epics and stories from `{epics_output}`
2. Load team's agile tool from `{team_config}`
3. Load templates from `{agile_templates}/{tool}/`
4. Transform stories to Rally/Jira format
5. Generate import CSV file

Output: `{rally_import}` (or jira-import.csv based on tool)
</action>
</step>

<step n="6" goal="Summary and next steps">
<action>
Show {user_name} a summary:

"✅ SAFe Delivery Cycle Complete!

Generated Artifacts:
1. PRD: `{prd_output}`
2. Architecture: `{architecture_output}`
3. Epics & Stories: `{epics_output}`
4. Rally/Jira Import: `{rally_import}`

Next Steps:
- Review the import file
- Import into Rally/Jira using the CSV
- Start sprint planning with `/bmad-bmm-workflows-sprint-planning`
- Begin development with `/bmad-bmm-workflows-dev-story`"
</action>
<template-output>delivery_cycle_summary</template-output>
</step>

</workflow>
