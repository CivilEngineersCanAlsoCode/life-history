# Project Context - Product Knowledge

> **🔴 IMPORTANT:** This is a SAMPLE template. Replace all `[PLACEHOLDER]` sections with your actual product information.

---

## Product Overview

**Product Name:** [Your Product Name]  
**Domain:** [e.g., Financial Services, E-Commerce, Healthcare]  
**Target Users:** [Primary user personas]

### Purpose
[Describe what problem this product solves and its value proposition]

---

## Business Context

### Strategic Goals
- [Goal 1]
- [Goal 2]
- [Goal 3]

### Key Metrics
- [Metric 1]: [Target]
- [Metric 2]: [Target]

---

## Technical Context

### Current Technology Stack
- **Frontend:** [e.g., React 18, Next.js 14]
- **Backend:** [e.g., Node.js, Spring Boot]
- **Database:** [e.g., PostgreSQL, MongoDB]
- **Cloud Provider:** [e.g., AWS, Azure, GCP]
- **CI/CD:** [e.g., Jenkins, GitHub Actions]

### Architecture Patterns
- [e.g., Microservices, Event-Driven, Serverless]

---

## Domain Knowledge

### Key Concepts
1. **[Concept 1]**: [Definition and importance]
2. **[Concept 2]**: [Definition and importance]
3. **[Concept 3]**: [Definition and importance]

### Business Rules
- **Rule 1:** [Description]
- **Rule 2:** [Description]

---

## Compliance & Security

### Regulatory Requirements
- [e.g., SOC 2, GDPR, HIPAA, PCI-DSS]

### Security Standards
- [e.g., OAuth 2.0, JWT, API Key Management]

---

## Integration Points

### External Systems
- **[System 1]:** [Purpose and integration method]
- **[System 2]:** [Purpose and integration method]

### APIs
- [List key APIs your product exposes or consumes]

---

## Coding Standards

### Code Style
- [Language-specific style guide, e.g., Airbnb for JavaScript]
- [Linting tools: ESLint, Prettier, etc.]

### Testing Requirements
- **Unit Test Coverage:** [e.g., minimum 80%]
- **Integration Tests:** [Required for all API endpoints]
- **E2E Tests:** [Required for critical user flows]

### Code Review Process
- [Describe your code review workflow]
- [Required approvers, checklists, etc.]

---

## Deployment & Operations

### Environments
- **Development:** [URL, purpose]
- **Staging:** [URL, purpose]
- **Production:** [URL, purpose]

### Deployment Process
- [Describe deployment workflow]
- [Release cadence, approval gates]

### Monitoring & Logging
- **Tools:** [e.g., Datadog, New Relic, CloudWatch]
- **Key Dashboards:** [List critical dashboards]

---

## Team Communication

### Slack Channels
- [#channel-name]: [Purpose]

### Meeting Cadence
- **Daily Standup:** [Time and format]
- **Sprint Planning:** [Frequency]
- **Retrospective:** [Frequency]

---

## Reference Documentation

### Existing Documentation
- [Link to Confluence/Notion/SharePoint]
- [Link to API Documentation]
- [Link to Architecture Diagrams]

### Onboarding Resources
- [Developer setup guide]
- [Product training materials]
