# Design-to-Spec Workflow Instructions

<critical>Invoke the Design Architect agent to create wireframes from requirements</critical>
<critical>Communicate all responses in {communication_language}</critical>

<workflow>

<step n="1" goal="Understand wireframe requirements">
<ask>
"What screen or feature do you need a wireframe for?

Please provide:
1. Screen name (e.g., 'Login Page', 'Dashboard', 'Checkout Flow')
2. Key UI components needed (e.g., 'username input, password input, submit button')
3. User flow or interaction (if applicable)
4. Reference to any existing screen from design catalog (optional)"
</ask>
</step>

<step n="2" goal="Invoke Design Architect">
<action>
Invoke the Design Architect agent located at:
`{project-root}/system-files/original/_bmad/enterprise/agents/design-architect.md`

Pass the user's requirements to the agent with instructions:
- Read design system from `{design_system}/manifest.json`
- Use components from `{design_system}/components/`
- Generate wireframe in Draw.io XML or Excalidraw JSON format
- Output filename: `{default_output_file}`
</action>
</step>

<step n="3" goal="Save and present wireframe">
<action>
1. Save the generated wireframe to `{default_output_file}`
2. Show the wireframe path to {user_name}
3. Provide instructions to open in Draw.io or Excalidraw
4. Ask if they want to:
   - Generate another wireframe
   - Modify this wireframe
   - Export to a different format
</action>
<template-output>wireframe_output</template-output>
</step>

</workflow>
