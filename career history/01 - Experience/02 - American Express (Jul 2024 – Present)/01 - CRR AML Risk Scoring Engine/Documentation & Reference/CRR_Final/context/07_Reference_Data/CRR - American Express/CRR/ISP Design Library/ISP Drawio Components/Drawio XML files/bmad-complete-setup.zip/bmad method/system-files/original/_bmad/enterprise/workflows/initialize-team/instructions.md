# Initialize Team Workflow Instructions

<critical>Communicate all responses in {communication_language}</critical>

<workflow>

<step n="1" goal="Welcome and explain workflow">
<action>
Greet {user_name} warmly and explain:

"This workflow will help you set up your team configuration and product context for the Enterprise Delivery module. I'll guide you through creating:
1. **Product Context** - Your product knowledge base
2. **Team Configuration** - Your team structure and agile practices
3. **Design System** - Links to your design assets
4. **Agile Tool Config** - Rally or Jira settings
5. **Architecture Standards** - Your tech stack and standards"
</action>
</step>

<step n="2" goal="Check existing configuration">
<action>
Check if the following files exist:
- `{product_knowledge}` (project-context.md)
- `{team_config}` (team-context.yaml)

If both exist:
- Ask if user wants to UPDATE existing config or START FRESH
- If update: load existing files and help modify them
- If fresh: proceed to create new files

If either is missing:
- Inform user we'll create them from sample templates
</action>
</step>

<step n="3" goal="Gather product knowledge">
<ask>
"Let's start with your product. Tell me about:
1. What product/system are you building?
2. What domain does it serve? (e.g., Financial Services, E-Commerce, Healthcare)
3. Who are the primary users?
4. What are the top 3 business goals?"
</ask>

<action>
Based on their answers, help them fill in the `{product_knowledge}` file.

Load the sample template from `{custom_folder}/product-knowledge/project-context.md` and guide them through replacing placeholders with actual values.

Key sections to fill:
- Product Overview
- Business Context & Strategic Goals
- Technology Stack
- Domain Knowledge & Business Rules
- Compliance & Security Requirements
</action>
</step>

<step n="4" goal="Configure team structure">
<ask>
"Now let's set up your team. Tell me:
1. What's your team name?
2. Who are the key roles? (Product Owner, Scrum Master, Tech Lead, Developers, QA, UX)
3. What's your Sprint duration? (typically 2 weeks)
4. Which agile tool do you use? (Rally, Jira, Azure DevOps, Other)"
</ask>

<action>
Using their answers, help populate `{team_config}` (team-context.yaml).

Load the sample from `{custom_folder}/team-config/team-context.yaml` and fill in:
- Team name and members
- Sprint configuration
- Agile tool selection
- Story point scale (Fibonacci recommended)
- Definition of Done
- Definition of Ready
</action>
</step>

<step n="5" goal="Set up design system (optional)">
<ask>
"Do you have a design system or design catalog?
- If YES: What's the path to your design system assets?
- If NO: We can skip this or use sample components for now."
</ask>

<action>
If YES:
- Ask them to place their design system files in `{custom_folder}/design-system/`
- Update `manifest.json` with their component catalog

If NO:
- Inform them the sample button component is available as a placeholder
- They can add more components later
</action>
</step>

<step n="6" goal="Configure agile templates">
<action>
Based on the agile tool selected in step 4 (Rally or Jira):

1. Show them the template location:
   - Rally: `{custom_folder}/agile-templates/rally/`
   - Jira: `{custom_folder}/agile-templates/jira/`

2. Ask if they want to customize field mappings now or use defaults

3. If customize:
   - Guide them through `field-mappings.yaml`   - Help map their custom fields (if any)

4. If defaults:
   - Inform them the sample templates will work for standard setups
</action>
</step>

<step n="7" goal="Architecture standards (optional)">
<ask>
"Do you have established architecture standards or an approved tech stack?
- If YES: Let's document them
- If NO: We can use sample standards as a starting point"
</ask>

<action>
If YES:
- Help them fill in `{custom_folder}/architecture-standards/tech-stack.yaml`
- Guide through security-requirements.md and cloud-infrastructure.md

If NO:
- Inform them samples are available as reference
- They represent industry best practices
- Can be customized later as standards evolve
</action>
</step>

<step n="8" goal="Save and verify">
<action>
1. Save all configuration files to `{custom_folder}/`
2. Verify file structure:
   - product-knowledge/project-context.md ✓
   - team-config/team-context.yaml ✓
   - design-system/ (optional) ✓
   - agile-templates/{tool}/ ✓
   - architecture-standards/ (optional) ✓

3. Show summary of what was configured

4. Explain next steps:
   "Your team is now initialized! You can:
   - Use `/domain-sentinel` to view/update product context
   - Use `/agile-bridge` to generate Rally/Jira import files
   - Use `/design-architect` to create wireframes
   - Run core BMAD workflows - they'll automatically use your configuration"
</action>
<template-output>configuration_summary</template-output>
</step>

</workflow>
