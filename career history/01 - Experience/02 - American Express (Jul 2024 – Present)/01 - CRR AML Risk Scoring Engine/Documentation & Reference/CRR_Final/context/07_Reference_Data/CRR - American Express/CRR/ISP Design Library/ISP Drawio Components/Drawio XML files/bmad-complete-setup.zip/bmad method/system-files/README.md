# ⚠️ BMAD System Files - DO NOT EDIT

**This folder contains the BMAD execution engine and is maintained by the BMAD core team.**

## 🔒 Read-Only Submodule

This directory is a **Git submodule** pointing to the `bmad-system-files` repository. 

**DO NOT edit files in this folder** unless you are:
- A BMAD core maintainer
- Debugging a critical system issue

## ✏️ For Customization

To customize BMAD behavior for your team, edit files in:
```
../custom/
├── product-knowledge/project-context.md
├── team-config/team-context.yaml
├── design-system/
├── agile-templates/
└── architecture-standards/
```

## 🔄 Updating BMAD System

To get the latest BMAD updates:
```bash
cd system-files
git pull
cd ..
```

After pulling updates, test with your configuration to ensure compatibility.

## 📂 Contents

- `.github/` - GitHub Copilot instructions
- `repo/` - Repository documentation and guides  
- `original/_bmad/` - Core BMAD modules (BMM, Enterprise, CIS, Core, BMB)

## 📚 Documentation

For BMAD usage documentation, see:
- Main README: `../README.md`
- Custom folder guide: `../custom/README.md`
