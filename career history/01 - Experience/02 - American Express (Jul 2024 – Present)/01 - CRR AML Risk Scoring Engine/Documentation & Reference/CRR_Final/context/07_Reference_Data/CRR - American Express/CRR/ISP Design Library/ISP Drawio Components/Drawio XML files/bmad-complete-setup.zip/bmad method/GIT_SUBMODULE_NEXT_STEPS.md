# Git Submodule Setup - Next Steps

## ✅ Completed So Far

1. **Folder Reorganization:**
   - Moved `.github/`, `repo/`, `original/` → `system-files/`
   - Renamed `_bmad-output/` → `output/`
   - `custom/` stays at root

2. **Path Updates:**
   - Updated 465+ files
   - `{project-root}/_bmad/` → `{project-root}/system-files/original/_bmad/`
   - `{project-root}/_bmad-output/` → `{project-root}/output/`

3. **Git Initialization:**
   - `system-files/` initialized as Git repo
   - 2 commits made (initial + path updates)
   - README files created

---

## 🚧 Remaining Steps (Manual - Requires GitHub)

### Step 1: Create `bmad-system-files` Repository on GitHub

1. Go to **https://github.com/klickbae8yt-star** (or your GitHub account)
2. Click **"New Repository"**
3. Repository name: `bmad-system-files`
4. Description: "BMAD Execution Engine - Read-Only System Files"
5. **Important:** Make it **Public** or **Private** (your choice)
6. **Do NOT initialize** with README, .gitignore, or license
7. Click **"Create Repository"**

### Step 2: Push `system-files/` to GitHub

```bash
cd "/Users/satvikjain/Downloads/bmad method/system-files"

# Add the remote (replace with your actual repo URL)
git remote add origin https://github.com/klickbae8yt-star/bmad-system-files.git

# Push to GitHub
git push -u origin main

# Verify
git remote -v

cd ..
```

### Step 3: Remove Local `system-files/` and Add as Submodule

```bash
cd "/Users/satvikjain/Downloads/bmad method"

# Remove the local folder (don't worry, it's pushed to GitHub)
rm -rf system-files

# Add as submodule
git submodule add https://github.com/klickbae8yt-star/bmad-system-files.git system-files

# Initialize the submodule
git submodule update --init --recursive
```

### Step 4: Commit to Workspace Repo

```bash
# Current repo is already connected to:
# https://github.com/CivilEngineersCanAlsoCode/Codex.git

# Add workspace files
git add .gitignore README.md custom/ .gitmodules

# Commit
git commit -m "Restructured to Git submodule architecture

- Moved BMAD engine to system-files/ submodule
- custom/ folder for team configuration
- output/ for generated files"

# Push to GitHub
git push
```

---

## 📋 What This Achieves

**Users cloning the workspace will do:**
```bash
git clone https://github.com/CivilEngineersCanAlsoCode/Codex.git
cd Codex
git submodule update --init --recursive
```

**They get:**
- `system-files/` (read-only BMAD engine from separate repo)
- `custom/` (tracked in workspace repo - editable)
- `output/` (gitignored - auto-generated)

---

## ⚠️ Important Notes

1. **system-files repo** must be created BEFORE adding as submodule
2. After pushing, verify on GitHub that all files are there
3. The workspace repo (Codex) will reference a specific commit of system-files
4. Users can update by: `cd system-files && git pull`

---

## 🆘 If Issues Occur

**Rollback:**
```bash
# You still have the original setup
# Just don't push the changes to GitHub
# Or create a new branch first for safety
```

**Test first:**
```bash
# Create a test branch before making changes
git checkout -b git-submodule-test

# Do all steps above

# If works: git checkout main && git merge git-submodule-test
# If broken: git checkout main && git branch -D git-submodule-test
```
