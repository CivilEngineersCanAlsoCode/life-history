# Enterprise Context Injection Rules

> **For All Core BMAD Agents (PM, Dev, Architect, SM, Analyst, UX, TEA, TechWriter, QuickFlow)**

This file defines how core agents load and utilize enterprise-specific context and configuration.

---

## 📂 Key Paths

### Product Knowledge & Configuration
- **Product Context:** `{project-root}/custom/product-knowledge/project-context.md`
  - Contains product domain knowledge, business rules, tech stack, coding standards
  - **REQUIRED** - Agents must load this before executing any work
  
- **Team Configuration:** `{project-root}/custom/team-config/team-context.yaml`
  - Defines team structure, Sprint config, agile tool (Rally/Jira)
  - **REQUIRED** - Used by SM, PM, and workflow orchestration

### Enterprise Assets
- **Design System:** `{project-root}/custom/design-system/`
  - UX Designer and Design Architect reference this for wireframes
  - Contains `manifest.json` with component catalog
  
- **Agile Templates:** `{project-root}/custom/agile-templates/`
  - Rally or Jira import templates and field mappings
  - Used by Agile Bridge agent for story export
  
- **Architecture Standards:** `{project-root}/custom/architecture-standards/`
  - Approved tech stack, security requirements, cloud patterns
  - Architect agent references this for decision-making

---

## 🤖 Enterprise Agents (Available for Invocation)

Core workflows can invoke these enterprise agents when needed:

1. **Domain Sentinel** - `{project-root}/system-files/original/_bmad/enterprise/agents/domain-sentinel.md`
   - **Purpose:** Product context guardian and configurator
   - **When to invoke:** During project initialization or context updates

2. **Agile Bridge** - `{project-root}/system-files/original/_bmad/enterprise/agents/agile-bridge.md`
   - **Purpose:** Transform BMAD stories to Rally/Jira import format
   - **When to invoke:** After creating epics & stories, before Sprint planning

3. **Design Architect** - `{project-root}/system-files/original/_bmad/enterprise/agents/design-architect.md`
   - **Purpose:** Generate design system-compliant wireframes
   - **When to invoke:** During UX design phase or wireframe creation

---

## ✅ Mandatory Fields & Handoff Protocol

### Before Starting Any Task
1. **Load `custom/product-knowledge/project-context.md`**
   - Treat as the "Product Knowledge Bible"
   - Use for domain context, tech stack, coding standards
   - If missing → inform user to run `/bmad-enterprise-workflows-initialize-team`

2. **Check `custom/team-config/team-context.yaml`**
   - Understand Sprint duration, team roles, agile tool
   - Use for workflow orchestration and story formatting

### Handoff to Enterprise Agents
When core workflows generate output (PRD, Architecture, Epics & Stories):
- Save to `{project-root}/output/` (standard BMAD output folder)
- Enterprise agents will read from this folder
- Agile Bridge transforms output to Rally/Jira format
- Design Architect creates wireframes using design system
e run `/domain-sentinel` to initialize."
3.  Do NOT proceed until context is established.
