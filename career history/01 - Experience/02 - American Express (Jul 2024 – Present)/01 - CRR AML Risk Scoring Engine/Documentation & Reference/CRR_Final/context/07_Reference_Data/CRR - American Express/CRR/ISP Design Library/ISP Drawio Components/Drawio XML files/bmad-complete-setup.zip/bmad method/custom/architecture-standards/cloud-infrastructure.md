# Cloud Infrastructure Standards

# 🔴 SAMPLE FILE - Adapt to your cloud provider and architecture

---

## Cloud Provider Strategy

### Primary Provider
**[AWS / Azure / GCP]** - Replace with your chosen provider

### Multi-Cloud Strategy
- **Primary:** [Provider Name] for all production workloads
- **Secondary:** [Provider Name] for DR/backup (if applicable)
- **Rationale:** [Cost, compliance, feature set]

---

## Architecture Patterns

### Reference Architecture

```
┌─────────────────────────────────────────────────────────┐
│                      CloudFront / CDN                    │
└────────────────────┬────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────┐
│                   API Gateway / ALB                      │
└────────────────────┬────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        │                         │
┌───────▼────────┐       ┌───────▼────────┐
│  Web App (ECS) │       │  API (ECS/EKS) │
│  Auto-Scaling  │       │  Auto-Scaling  │
└───────┬────────┘       └───────┬────────┘
        │                        │
        └────────────┬───────────┘
                     │
        ┌────────────▼───────────┐
        │   RDS (PostgreSQL)     │
        │   Multi-AZ Enabled     │
        │   Automated Backups    │
        └────────────────────────┘
```

### Deployment Zones
- **Multi-AZ:** All production services across ≥2 availability zones
- **Multi-Region:** For DR if required by compliance

---

## Compute Resources

### Container Orchestration
- **Platform:** [ECS / EKS / AKS / GKE]
- **Instance Types:** [e.g., t3.medium for non-prod, c5.large for prod]
- **Auto-Scaling Policy:**
  - Scale out: CPU > 70% for 2 minutes
  - Scale in: CPU < 30% for 5 minutes
  - Min instances: 2, Max instances: 20

### Serverless (if applicable)
- **Functions:** [AWS Lambda / Azure Functions / Cloud Functions]
- **Timeout:** Maximum 15 minutes (or 900 seconds)
- **Memory Allocation:** 512MB to 3GB based on workload

---

## Networking

### VPC Design
- **CIDR Block:** `10.0.0.0/16` (or your range)
- **Subnets:**
  - Public Subnet: `10.0.1.0/24`, `10.0.2.0/24` (for load balancers)
  - Private Subnet: `10.0.10.0/24`, `10.0.11.0/24` (for app servers)
  - Database Subnet: `10.0.20.0/24`, `10.0.21.0/24` (isolated)

### Load Balancing
- **Type:** Application Load Balancer (Layer 7)
- **Health Checks:** Interval 30s, Timeout 5s, Unhealthy threshold 2
- **TLS Termination:** At load balancer level

### DNS
- **Service:** Route 53 / Azure DNS / Cloud DNS
- **TTL:** 60 seconds for production, 300 seconds for non-prod
- **Health Checks:** DNS failover enabled

---

## Data Storage

### Databases
- **Primary DB:** RDS PostgreSQL 15 (or your database)
  - **Instance Type:** db.t3.large (non-prod), db.r5.xlarge (prod)
  - **Multi-AZ:** Enabled for production
  - **Backups:** Daily automated backups, 7-day retention
  - **Encryption:** Enabled (AES-256)

- **Caching Layer:** ElastiCache Redis
  - **Instance Type:** cache.t3.medium
  - **Cluster Mode:** Enabled for prod

### Object Storage
- **Service:** S3 / Azure Blob / Cloud Storage
- **Lifecycle Policies:**
  - Transition to Glacier after 90 days (for archives)
  - Delete after 1 year (for temporary files)
- **Versioning:** Enabled for critical buckets
- **Encryption:** Server-side encryption (SSE-S3 or SSE-KMS)

---

## Security & Compliance

### IAM Policies
- **Principle:** Least privilege access
- **Service Accounts:** Separate IAM roles per service
- **MFA:** Required for console access
- **Access Keys:** Rotate every 90 days

### Network Security
- **Security Groups:** Restrictive inbound rules only
- **NACLs:** Additional layer for sensitive subnets
- **VPN:** Site-to-site VPN for on-prem connectivity
- **WAF:** Web Application Firewall enabled on ALB/CloudFront

### Secrets Management
- **Service:** AWS Secrets Manager / Azure Key Vault / GCP Secret Manager
- **Rotation:** Automatic rotation every 90 days
- **Access Logging:** All secret access logged

---

## Monitoring & Logging

### Application Performance Monitoring
- **Tool:** [Datadog / New Relic / Dynatrace]
- **Metrics Collected:**
  - Request latency (p50, p95, p99)
  - Error rates
  - Throughput (requests/sec)
  - Resource utilization (CPU, memory)

### Infrastructure Monitoring
- **Tool:** CloudWatch / Azure Monitor / Stackdriver
- **Alarms:**
  - CPU > 80% for 5 minutes
  - Memory > 85%
  - Disk space > 80%
  - Application errors > 1% of requests

### Logging
- **Aggregation:** CloudWatch Logs / Azure Monitor / Cloud Logging
- **Retention:** 30 days for app logs, 1 year for audit logs
- **Search:** Elasticsearch / CloudWatch Insights

### Distributed Tracing
- **Tool:** AWS X-Ray / Azure Application Insights / Cloud Trace
- **Sampling Rate:** 10% in production, 100% in non-prod

---

## Disaster Recovery & Business Continuity

### Backup Strategy
- **Database Backups:** Daily automated backups + 7-day retention
- **Snapshot Frequency:** Weekly EC2/EBS snapshots
- **Cross-Region Replication:** Enabled for critical data

### Recovery Objectives
- **RTO (Recovery Time Objective):** 4 hours
- **RPO (Recovery Point Objective):** 1 hour
- **Failover Testing:** Quarterly DR drills

### High Availability
- **Multi-AZ Deployment:** All production services
- **Auto-Scaling:** Automatic replacement of failed instances
- **Health Checks:** Continuous health monitoring

---

## Cost Optimization

### Resource Tagging Strategy
- **Required Tags:**
  - `Environment`: dev / staging / prod
  - `Team`: [team-name]
  - `CostCenter`: [cost-center-id]
  - `Project`: [project-name]

### Cost Controls
- **Reserved Instances:** For predictable workloads (save 30-50%)
- **Savings Plans:** Commit to 1-3 year usage
- **Spot Instances:** For non-critical batch jobs
- **Auto-Shutdown:** Non-prod environments shut down after hours

### Budget Alerts
- Alert at 80% of monthly budget
- Hard limit at 120% (prevent runaway costs)

---

## Deployment & CI/CD

### Infrastructure as Code (IaC)
- **Tool:** [Terraform / CloudFormation / ARM Templates / Deployment Manager]
- **State Management:** Remote state in S3 with versioning
- **Approval:** Require manual approval for prod changes

### CI/CD Pipeline
- **Build:** Compile, lint, test (unit + integration)
- **Security Scan:** SAST, container image scanning
- **Deploy:** Blue-green deployment to minimize downtime
- **Rollback:** Automatic rollback if health checks fail

---

## Compliance & Governance

### Audit Logging
- **Service:** CloudTrail / Azure Activity Log / Cloud Audit Logs
- **Retention:** 1 year minimum
- **Alerts:** Real-time alerts for sensitive API calls

### Compliance Frameworks
- **SOC 2 Type II:** Annual audit
- **ISO 27001:** If required
- **HIPAA / PCI-DSS:** If handling sensitive data

---

## Contact & Escalation

- **Cloud Platform Team:** cloud-platform@example.com
- **Infrastructure Incidents:** infrastructure-oncall@example.com
- **Cost Optimization:** finops@example.com
